chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    var divBtn = document.createElement("div");
    divBtn.innerHTML = "<button id='downloadBtn'>download</button><button id='copyBtn'>copy</button>";
    var clickEvt = new MouseEvent('click',{
        bubbles:true,
        cancelable:true,
        view:window
    });

    var data = [];
    var timer;
    document.querySelector(".nav").appendChild(divBtn);
    function clickSpanEvt(){
        let spanDom = document.querySelector(".cell.day.selected");
        if(!spanDom){ 
            return
         }
        if( Number(spanDom.textContent) === 1){
            document.querySelector(".prev").dispatchEvent(clickEvt);
            setTimeout(function(){
                document.querySelector(".cell.day:last-child").dispatchEvent(clickEvt);
            },2000)
        }else{
            spanDom.previousSibling.dispatchEvent(clickEvt);
        }   
    }
    function parseData(){
        clickSpanEvt();
        setTimeout(function(){
            let answerBtn = document.querySelector(".bottom-content").lastChild;
            if(!answerBtn){ return}
            if(answerBtn.textContent==="显示答案"){
                answerBtn.dispatchEvent(clickEvt);
            };
        },4000)
        setTimeout(function(){
            let point = document.querySelector("p[title]").getAttribute("title").trim() + "\n";
            let questionTag = document.querySelector(".title-left").textContent.trim() + "\n";
            let question = document.querySelector(".content-stem").lastChild.textContent.trim()+"\n";
            let options = document.querySelectorAll('.content-option');
            let answer = document.querySelector(".day-test-h2:last-child").textContent.trim()+"\n" + document.querySelector(".analysis").textContent.trim()+"\n";
            let qOption = "";
            for(let i=0;i<options.length;i++){
                qOption += options[i].textContent.trim()+"\n";
            }
            
            if(point && questionTag && question && answer){
                data.push(point + questionTag + question + qOption + answer +"-----\n");
            }
        },8000) 
    }
    document.querySelector("#downloadBtn").addEventListener("click",function(){
        
        clearInterval(timer);
        timer = setInterval(function(){
            parseData();
        },15000);   
    });
    document.querySelector("#copyBtn").addEventListener("click",function(){
        clearInterval(timer);

        const blob = new Blob(data);
        const fileStream = streamSaver.createWriteStream('sample.txt', {
            size: blob.size // Makes the percentage visiable in the download
        })
    
        // One quick alternetive way if you don't want the hole blob.js thing:
        // const readableStream = new Response(
        //   Blob || String || ArrayBuffer || ArrayBufferView
        // ).body
        const readableStream = blob.stream()
    
        // more optimized pipe version
        // (Safari may have pipeTo but it's useless without the WritableStream)
        if (window.WritableStream && readableStream.pipeTo) {
            return readableStream.pipeTo(fileStream)
            .then(() => console.log('done writing'))
        }
    
        // Write (pipe) manually
        window.writer = fileStream.getWriter()
    
        const reader = readableStream.getReader()
        const pump = () => reader.read()
            .then(res => res.done
                ? writer.close()
                : writer.write(res.value).then(pump))
    
        pump()
    })
    sendResponse({ fromcontent: "This message is from content.js" });
});