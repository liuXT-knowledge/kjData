import * as vscode from "vscode";
import createTable from "./createTable";

export function activate(context: vscode.ExtensionContext): void {
  context.subscriptions.push(
	vscode.commands.registerCommand("kjTable.colorFont",async() => {
	  const editor: vscode.TextEditor | undefined =
        vscode.window.activeTextEditor;

      if (editor === undefined) {
        return vscode.window.showErrorMessage("TextEditor is not active!");
      }

	  const document = editor.document;
    let textSel = editor.selection;
    editor.edit(editBuilder => {
      const range = textSel.isEmpty ? document.getWordRangeAtPosition(textSel.start) || textSel : textSel;
      let word = document.getText(textSel).trim();
      if(word.length > 0){
        let reg1 = /<font.*?>/;
        let reg2 = /<\/font>/;
        
        if(word.search(reg1) !== -1 && word.search(reg2) !== -1){
          let newWord = word.replace(reg1,"").replace(reg2,"");
          editBuilder.replace(range,newWord.toString());
        }else {
          let reversed = '<font color="#ff3b30">' + word + "</font>";
          editBuilder.replace(range, reversed);
        }
      }else{
        editBuilder.insert(range.end,"c");
      } 
    });
	})
  );
  context.subscriptions.push(
    vscode.commands.registerCommand("kjTable.createTable", async () => {
      const editor: vscode.TextEditor | undefined =
        vscode.window.activeTextEditor;

      if (editor === undefined) {
        return vscode.window.showErrorMessage("TextEditor is not active!");
      }

      let cuesorPosition = editor.selection.active;
      let lineText = editor.document.lineAt(cuesorPosition).text.trim();

      if(lineText.length === 2 ){
        let row = Number(lineText.charAt(0));
        let column = Number(lineText.charAt(1));
        if(1<row && row< 10 && 1<column && column<10){
          await editor.edit(
            (builder: vscode.TextEditorEdit): void => {
              builder.delete(editor.selection);
              builder.insert(
                editor.selection.start,
                createTable(row, column)
              );
            }
          );
        }else{
          vscode.window.showErrorMessage("行列数≥2");
        }
      }else{
        vscode.window.showErrorMessage("要两个纯数字");
      }
    })
  );
}

// This method is called when your extension is deactivated
export function deactivate() {}
