export default function createTable(
    tableRows: number,
    tableCols: number
  ): string {

    let tableText = "<table>\n";

    for(let i=0;i < tableCols;i++){
        tableText +="  <th align='center'></th>\n";
    }

    for (let i = 0; i < tableRows; i++) {
        tableText += "  <tr>\n";
        for (let j=0;j<tableCols;j++){
            tableText += "    <td></td>\n";
        }
        tableText += "  </tr>\n";
    }
    tableText += "</table>";
  
    return tableText;
  }